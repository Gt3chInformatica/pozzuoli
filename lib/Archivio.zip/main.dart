import 'package:flutter/material.dart';
import 'SendingReport.dart';

void main() {
  runApp(LoginDemo());
}

class LoginDemo extends StatefulWidget {
  @override
  _LoginDemoState createState() => _LoginDemoState();
}

class _LoginDemoState extends State<LoginDemo> {
  // Initially password is obscure

  final _controllerEmail = new TextEditingController();
  final _controller = new TextEditingController();

// dispose it when the widget is unmounted
  @override
  void dispose() {
    _controller.dispose();
    _controllerEmail.dispose();
    super.dispose();
  }

  void _submit() {
    final text = _controller.value.text;
    final emailText = _controllerEmail.value.text;

    if(text == "" && emailText != ""){
      Widget okButton = TextButton(
        child: Text("OK"),
        onPressed: () {
          Navigator.pop(context);
        },
      );
      showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
                title: Text("Attenzione!"),
                content: Text("Impossibile effettuare il login! Password non inserita!"),
                actions: [
                  okButton,
                ]
            );
          }
      );
    }else if(text != "" && emailText == ""){
      Widget okButton = TextButton(
        child: Text("OK"),
        onPressed: () {
          Navigator.pop(context);
        },
      );
      showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
                title: Text("Attenzione!"),
                content: Text("Impossibile effettuare il login! Indirizzo e-mail non inserito!"),
                actions: [
                  okButton,
                ]
            );
          }
      );
    }else if(text != "" && emailText != ""){
     /* Navigator.push(
          context, MaterialPageRoute(builder: (_) => MyAppMap()));*/
    }else if(text == "" && emailText == ""){
      Widget okButton = TextButton(
        child: Text("OK"),
        onPressed: () {
          Navigator.pop(context);
        },
      );
      showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: Text("Attenzione!"),
              content: Text("Impossibile effettuare il login! Compilare tutti i campi!"),
                actions: [
                  okButton,
                ]
            );
          }
      );
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text("Login"),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Padding(
              padding: EdgeInsets.all(10.0),
              child: Center(
                child: Container(
                    width: 200,
                    height: 150,
                    /*decoration: BoxDecoration(
                        color: Colors.red,
                        borderRadius: BorderRadius.circular(50.0)),*/
                    child: Image.asset('asset/images/oly_Logo.png')),
              ),
            ),
          /*  Padding(
                padding: checkEmail == null ? const EdgeInsets.all( 68.0) : const EdgeInsets.all(0.0),
                child: Text(checkEmail == null ? 'Indirizzo e-mail non valido' : ''),
            ),*/
            Container(
              height: 50,
              width: 250,
              decoration: BoxDecoration(
                  color: Colors.blue, borderRadius: BorderRadius.circular(20)),
              child: ElevatedButton(
                onPressed: () {
                  _submit();
                /*  _controller.value.text.isNotEmpty ? Navigator.push(
                      context, MaterialPageRoute(builder: (_) => HomePage())) : null;*/
                 /* Navigator.push(
                      context, MaterialPageRoute(builder: (_) => HomePage()));*/
                /*  setState(() {
                    _text.text.isEmpty ? _validate = true : _validate = false;
                  });*/
                },
                child: Text(
                  'Login',
                  style: Theme.of(context).textTheme.headline6,
                ),
              ),
            ),
            SizedBox(
              height: 80,
            ),
         //   Text('New User? Create Account')
          ],
        ),
      ),
    );
  }
}
